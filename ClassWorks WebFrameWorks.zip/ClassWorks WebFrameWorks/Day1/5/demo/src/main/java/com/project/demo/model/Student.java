package com.project.demo.model;

public class Student {
    public String studentName, message;

    public Student(String a, String b) {
        studentName = a;
        message = b;
    }
}
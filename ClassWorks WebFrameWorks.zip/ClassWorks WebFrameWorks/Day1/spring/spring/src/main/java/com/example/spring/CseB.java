package com.example.spring;

public class CseB {
    
    public int nos;
    public String dept;
    public String url;
    public CseB(int n,String d,String u)
    {
        nos=n;
        dept=d;
        url=u;
    }
}

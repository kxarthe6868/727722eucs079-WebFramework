package com.example.classwork.controller;

public class Claus {
    public int nos;
    public String name;

    public Claus(int nos,String name){
        this.nos=nos;
        this.name=name;
    }
}

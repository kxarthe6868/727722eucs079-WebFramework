package com.example.classwork.controller;

import org.springframework.stereotype.Service;

@Service
public class ReportService {
    public Claus claus(String pop)
    {
        Claus c = new Claus(12, "man");
        return c;
    }
}

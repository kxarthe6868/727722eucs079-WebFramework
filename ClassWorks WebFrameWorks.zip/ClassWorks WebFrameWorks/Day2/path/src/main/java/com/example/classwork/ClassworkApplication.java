package com.example.classwork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassworkApplication.class, args);
	}

}

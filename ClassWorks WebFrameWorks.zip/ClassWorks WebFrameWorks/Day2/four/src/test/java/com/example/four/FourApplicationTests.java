package com.example.four;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FourApplicationTests {

	@Test
	void contextLoads() {
	}

}

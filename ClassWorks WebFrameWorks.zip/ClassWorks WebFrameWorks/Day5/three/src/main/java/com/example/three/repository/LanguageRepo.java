package com.example.three.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.three.model.Language;

public interface LanguageRepo extends JpaRepository<Language,Integer>{

     
}
